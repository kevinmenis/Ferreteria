<!--  ../controllers/Partials/header.php  -->

<?php

	require '../fw/fw.php' ;
	require '../views/Header.php' ;

	$v = new Header ;

	$v->render() ;

?>

