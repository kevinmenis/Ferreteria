<!--  ../controllers/Partials/footer.php  -->

<?php

	require '../fw/fw.php' ;
	require '../views/Footer.php' ;

	$v = new Footer ;

	$v->render() ;

?>

