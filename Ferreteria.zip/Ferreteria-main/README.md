# Ferreteria

Este proyecto consiste en gestionar un negocio en este caso: "Casa Hogar" en la cual las funciones que hace son:
Poder agregar, modificar y eleminar prestamos o fiados y de estos poder ver la lista.
Del lado de ventas, ingresar y eliminar (solamente la de la fecha acutal), ver las listas de ventas del dia, mes, año.
Ver estadísticas del mes y del año: total, promedio, minima, maxima entre otras.
Y también ver lista de productos, porder cambiar tanto el nombre u otro atributo y modificar el precio de toda una lista ingresando el porcentaje de lo que quieras aumentar. Por ej. tengo 2 productos A: $100 y B: $200 al ingresar 10, aumentaria un 10% y quedaria asi: A: $110 y B: $220.

En las carpetas esta el codigo y una llamada 'imagenes del proyecto' en la que van a ver como esta hecho.

Para realizar este programa use la modalidad de MVC en PHP. Lenguajes utilizados: HTML - PHP - Bootstrap 4 - CSS - JS - base de datos MySQL.
