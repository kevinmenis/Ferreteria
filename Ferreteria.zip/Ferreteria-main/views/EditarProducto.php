<!--  ../views/EditarProducto.php  -->

<?php 

	
	class EditarProducto extends View {

		public $result ;

	}