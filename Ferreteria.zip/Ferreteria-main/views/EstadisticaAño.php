<!--  ../views/EstadisticaAño.php  -->

<?php 

	class EstadisticaAño extends View {

		public $totalAño ;
		public $mesMin ;
		public $mesMax ;
		public $record ;
		public $nombreMes ;
		
	}
