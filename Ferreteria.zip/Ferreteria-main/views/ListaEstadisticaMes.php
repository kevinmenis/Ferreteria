<?php 

/* ../views/ListaEstadisticaMes.php */

	class ListaEstadisticaMes extends View {

		public $totalMes ;
		public $promedioDia ;
		public $diaMax ;
		public $diaMin ;
		public $nombreMes ;

	}

?>