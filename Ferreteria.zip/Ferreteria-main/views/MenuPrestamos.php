<!--  ../views/MenuPrestamos.php  -->

<?php 


	class MenuPrestamos extends View {
		

	}