<!--  ../views/EliminarFiado.php  -->

<?php 

	
	class EliminarFiado extends View {

		public $result ;

	}