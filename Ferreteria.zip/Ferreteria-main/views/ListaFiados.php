<!--  ../views/ListaFiados.php  -->

<?php 

	class ListaFiados extends View {
	
		public $todos ;

	}


