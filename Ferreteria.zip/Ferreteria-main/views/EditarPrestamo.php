<!--  ../views/EditarPrestamo.php  -->

<?php 

	
	class EditarPrestamo extends View {

		public $result ;

	}