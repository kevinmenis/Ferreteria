<!--  ../views/Partials/Footer.php  -->

<?php

	class Footer extends view {
  

	}	

