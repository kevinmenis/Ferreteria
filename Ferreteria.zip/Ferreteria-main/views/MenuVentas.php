<!--  ../views/MenuVentas.php  -->

<?php 


	class MenuVentas extends View {


	}