<!--  ../views/ListaFerreteria.php  -->

<?php 


class ListaFerreteria extends View {
	
	public $todos ;

}
