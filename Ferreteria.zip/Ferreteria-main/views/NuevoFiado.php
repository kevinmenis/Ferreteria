<!--  ../views/NuevoFiado.php  -->

<?php 

	class NuevoFiado extends View {
	
	
	}

