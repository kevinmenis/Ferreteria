<!--  ../views/ListaVentasDelAño.php  -->

<?php 


	class ListaVentasDelAño extends View {

		public $lista ;
		public $total ;

	}