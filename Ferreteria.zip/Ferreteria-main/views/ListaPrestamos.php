<!--  ..views/ListaPrestamos.php  -->

<?php 

	class ListaPrestamos extends View {
		
		public $todos ;

	}