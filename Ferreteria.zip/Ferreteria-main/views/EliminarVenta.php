<!--  ../views/EliminarVenta.php  -->

<?php 

	
	class EliminarVenta extends View {

		public $result ;

	}