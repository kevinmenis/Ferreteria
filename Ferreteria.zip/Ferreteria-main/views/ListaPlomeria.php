<!--  ../views/ListaPlomeria.php  -->

<?php 


class ListaPlomeria extends View {
	
	public $todos ;
	public $todos_aux ;

}
