<!--  ../views/ListaSanitarios.php  -->

<?php 


class ListaSanitarios extends View {
	
	public $todos ;

}
