<!--  ../views/ListaElectricidad.php  -->

<?php 


class ListaElectricidad extends View {
	
	public $todos ;

}
