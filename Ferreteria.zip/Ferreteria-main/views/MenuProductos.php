<!--  ../views/MenuProductos.php-->

<?php 


	class MenuProductos extends View {

	}