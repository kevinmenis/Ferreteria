<!--  ../views/EliminarPrestamo.php  -->

<?php 

	
	class EliminarPrestamo extends View {

		public $result ;

	}