<!--  ../views/MenuSanitarios.php-->

<?php 


	class MenuSanitarios extends View {

	}