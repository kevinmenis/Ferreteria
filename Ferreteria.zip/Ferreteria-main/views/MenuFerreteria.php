<!--  ../views/MenuFerreteria.php-->

<?php 


	class MenuFerreteria extends View {

	}