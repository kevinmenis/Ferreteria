<!--  ../views/EditarFiado.php  -->

<?php 

	
	class EditarFiado extends View {

		public $result ;

	}