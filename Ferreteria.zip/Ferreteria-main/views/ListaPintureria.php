<!--  ../views/ListaPintureria.php  -->

<?php 


class ListaPintureria extends View {
	
	public $todos ;

}
