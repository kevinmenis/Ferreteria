<!--  ../views/nuevoPrestamo.php  -->

<?php 

	
	class NuevoPrestamo extends View {

	}